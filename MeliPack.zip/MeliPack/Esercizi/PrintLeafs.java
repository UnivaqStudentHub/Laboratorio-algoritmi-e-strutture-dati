package melipack.Esercizi;
/*
Realizzare il metodo statico
public static <E> void printLeafs(BinaryNode<E> root)
che stampa il contenuto di tutte le foglie dell’albero binario radicato in root, seguendo
l’ordine da sinistra a destra.
 */


import melipack.tree.binarytree.BinaryNode;

public class PrintLeafs {
    public static <E> void printLeafs(BinaryNode<E> root){

    }
}
