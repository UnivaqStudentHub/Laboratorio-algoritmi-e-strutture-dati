package melipack.examples;

import melipack.heap.ArrayListBinaryHeap;
import melipack.heap.BinaryHeap;
import melipack.network.unweighted.UnweightedGraph;
import melipack.network.unweighted.UnweightedNetwork;
import melipack.network.weighted.Graph;
import melipack.network.weighted.Network;
import melipack.network.weighted.UndirectedNetwork;
import melipack.set.BinarySearchTree;
import melipack.tree.BinaryTree;
import melipack.tree.binarytree.LinkedBinaryTree;

import java.util.ArrayList;
import java.util.List;

public class Examples {
    private static List<Integer> randomList(int size, int max) {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add((int) (Math.random() * max));
        }
        return list;
    }
    private static Integer[] orderedInts = {0,1,2,3,4,5,6,7,8,9,10,11,12};
    public static BinarySearchTree<Integer> randomBinarySearchTree(int size){
        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        bst.addAll(randomList(size, 20));
        return bst;
    }
    public static BinaryTree<Integer> randomBinaryTree(int size){
        List<Integer> list = randomList(size, 20);
        return new LinkedBinaryTree<>(list.toArray(new Integer[0]));
    }
    public static BinaryTree<Integer> orderedBinaryTree(){
        return new LinkedBinaryTree<>(orderedInts);
    }
    public static BinarySearchTree<Integer> orderedBinarySearchTree(){
        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        bst.addAll(new ArrayList<>(List.of(orderedInts)));
        return bst;
    }
    public static BinaryHeap<Integer> randomBinaryHeap(int size){
        List<Integer> list = randomList(size, 20);
        return new ArrayListBinaryHeap<>(list.toArray(new Integer[0]));
    }
    public static BinaryHeap<Integer> orderedBinaryHeap(){
        return new ArrayListBinaryHeap<>(orderedInts);
    }
    public static UnweightedGraph<Integer> randomUnweightedGraph(int size, float fullness){
        UnweightedGraph<Integer> graph = new UnweightedNetwork<>();
        for (int i = 0; i < size; i++) {
            graph.addVertex(i);
        }
        for (int i = 0; i < size; i++) {
            int oneEdge = i;
            while(size > 1){ // avoid self-loops
                oneEdge = (int) (Math.random() * size);
                if(oneEdge != i){
                    graph.addEdge(i, oneEdge);
                    break;
                }
            }
            for (int j = 0; j < size; j++) {
                // add a random number of edges
                if (Math.random() < fullness && j != oneEdge) graph.addEdge(i, j);
            }
        }
        return graph;
    }
    static private Graph<Integer, Double> populateWeightedGraph(Graph<Integer, Double> graph, int size, float fullness, int maxWeight){
        for (int i = 0; i < size; i++) {
            graph.addVertex(i);
        }
        for (int i = 0; i < size; i++) {
            int oneEdge = i;
            while(size > 1){ // avoid self-loops
                oneEdge = (int) (Math.random() * size);
                if(oneEdge != i){
                    graph.addEdge(i, oneEdge,(double) ((int) (Math.random() * maxWeight)));
                    break;
                }
            }
            for (int j = 0; j < size; j++) {
                // add a random number of edges
                if (Math.random() < fullness && j != oneEdge) graph.addEdge(i, j, (double) ((int) (Math.random() * maxWeight)));
            }
        }
        return graph;
    }
    public static Network<Integer> randomWeightedDirectedGraph(int size, float fullness, int maxWeight){
        Network<Integer> graph = new Network<>();
        return (Network<Integer>) populateWeightedGraph(graph, size, fullness, maxWeight);
    }
    public static UndirectedNetwork<Integer> randomWeightedUndirectedGraph(int size, float fullness, int maxWeight){
        UndirectedNetwork<Integer> graph = new UndirectedNetwork<>();
        return (UndirectedNetwork<Integer>) populateWeightedGraph(graph, size, fullness, maxWeight);
    }
    private static Graph<Integer, Double> populateWeightedGraph(Graph<Integer, Double> graph){
        int size = 11;
        for (int i = 1; i < size; i++) {
            graph.addVertex(i);
        }
        graph.addEdge(1, 8, 14.0);
        graph.addEdge(8, 2, 3.0);
        graph.addEdge(2, 3, 3.0);
        graph.addEdge(3, 4, 4.0);
        graph.addEdge(4, 5, 5.0);
        graph.addEdge(6, 7, 6.0);
        graph.addEdge(3, 6, 2.0);
        graph.addEdge(5, 7, 1.0);
        graph.addEdge(7, 11, 10.0);
        graph.addEdge(11, 10, 8.0);
        graph.addEdge(9, 10, 5.0);
        graph.addEdge(8, 9, 7.0);
        graph.addEdge(6, 9, 9.0);
        graph.addEdge(2, 6, 2.0);
        return graph;
    }
    public static Network<Integer> weightedDirectedNetwork(){
        Network<Integer> graph = new Network<>();
        return (Network<Integer>) populateWeightedGraph(graph);
    }
    public static UndirectedNetwork<Integer> weightedUndirectedNetwork(){
        UndirectedNetwork<Integer> graph = new UndirectedNetwork<>();
        return (UndirectedNetwork<Integer>) populateWeightedGraph(graph);
    }
    public static UnweightedGraph<Integer> unweightedGraph(){
        UnweightedGraph<Integer> graph = new UnweightedNetwork<>();
        int size = 11;
        for (int i = 1; i < size; i++) {
            graph.addVertex(i);
        }
        graph.addEdge(1, 8);
        graph.addEdge(8, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        graph.addEdge(4, 5);
        graph.addEdge(6, 7);
        graph.addEdge(3, 6);
        graph.addEdge(5, 7);
        graph.addEdge(7, 11);
        graph.addEdge(11, 10);
        graph.addEdge(9, 10);
        graph.addEdge(8, 9);
        graph.addEdge(6, 9);
        graph.addEdge(2, 6);
        return graph;
    }
}
